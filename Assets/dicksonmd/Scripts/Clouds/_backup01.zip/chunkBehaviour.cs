using UnityEngine;
using System.Collections.Generic;

public class chunkBehaviour : MonoBehaviour {

    public bool debugBoundary = false;
    public bool debugColor = false;
    public Color defaultColor;

    [HideInInspector]
    public int chunkSize = 8000;
    private int size = 4000;

    [HideInInspector]
    public int cloudCount = 10;
    public ParticleSystem[] cloudPrefabs;
    public Vector3 cloudScale;
    public int seed;

    private List<ParticleSystem> clouds = new List<ParticleSystem>(10);

    private System.Random rand = new System.Random();

    private int _chunkID = -1;
    public int chunkID
    {
        get
        {
            return this._chunkID;
        }
        set
        {
            this._chunkID = value;
            this.transform.GetChild(0).GetComponent<treadmillBehaviour>().chunkID = value;
        }
    }

	// Use this for initialization
	void Start () {
        this.rand = new System.Random(this.seed);
        // divide partition size by 2 to facilitate randomization
        this.size = this.chunkSize / 2;

	    // create a bunch of clouds in its control
        int x, y, z, cloudID;
        Color color;
        for (int i = 0; i < this.cloudCount; i++)
        {
            x = this.rand.Next(-1 * size, 1 * size);
            y = this.rand.Next(-1 * size, 1 * size);
            z = this.rand.Next(-1 * size, 1 * size);
            cloudID = this.rand.Next(3);
            color = chooseColorByDebug(cloudID);

            Vector3 pos = this.transform.position + new Vector3(x,y,z);
            ParticleSystem cloud = this.createCloud(cloudID, pos, color);
            cloud.transform.localScale = this.cloudScale;
            this.clouds.Add(cloud);
            cloud.transform.parent = this.transform;
        }
        //Debug.Log("cloud count:"+ this.cloudCount);

        Transform chunkBoundary = this.transform.GetChild(1);
        Transform chunkTrigger = this.transform.GetChild(0);
        chunkTrigger.GetComponent<treadmillBehaviour>().chunkSize = this.chunkSize;

        chunkBoundary.localScale = new Vector3(
            this.chunkSize * 1f,
            this.chunkSize * 1f,
            this.chunkSize * 1f
        );
        chunkTrigger.localScale = new Vector3(
            this.chunkSize * 1.25f,
            this.chunkSize * 1.25f,
            this.chunkSize * 1.25f
        );
        if (this.chunkID == 14) { /* do nothing for now */}
        if (!this.debugBoundary)
        {
            chunkTrigger.renderer.enabled = false;
            chunkBoundary.renderer.enabled = false;
        }
	}
	
	// Update is called once per frame
	void Update () {}

    // when its chunkTrigger is triggered
    public void TreadmillTriggered(Vector3 area)
    {
        this.transform.parent.GetComponent<cloudManagerBehaviour>().ChunkSwap(area);

    }

    // create a new cloud using prefab particle system
    ParticleSystem createCloud(int cloudID, Vector3 pos,Color c){

        ParticleSystem p = Instantiate(cloudPrefabs[cloudID],pos,Random.rotation) as ParticleSystem;
        p.startColor = c;

        return p;
    }

    // create a color according to hex color values
    static Color rgba(int r,int g,int b, float a){
        return new Color(1.0f*r/255,1.0f*g/255,1.0f*b/255,a);
    }

    // returns different colors if debug, else returns a designated color (with differernt alpha).
    Color chooseColorByDebug(int cloudID)
    {
        Color color;
        if (this.debugColor)
        {
            color = new HSBColor(0.3f * cloudID, 0.4f, 1, 0.7f).ToColor();
        }
        else
        {
            HSBColor temp = HSBColor.FromColor(this.defaultColor);
            color = new HSBColor(
                temp.h,
                temp.s,
                temp.b,
                (float)(this.rand.NextDouble() * 0.5 + 0.3)
            ).ToColor();
        }
        return color;
    }
    
}
